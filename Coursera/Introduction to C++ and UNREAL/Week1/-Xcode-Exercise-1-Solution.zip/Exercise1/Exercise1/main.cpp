// Copyright A.T. Chamillard. All Rights Reserved.

#include <iostream>

/**
 * Exercise 1 solution
 * @param argc command-line argument count
 * @param argv command-line arguments
 * @return exit status
 */
int main(int argc, const char * argv[])
{
    // Problem 1: output name
    std::cout << "My name: Dr. T\n";
    
    // Problem 2: output best friend or nemesis
    std::cout << "My nemesis: Administrators\n";
    
    return 0;
}
