// Copyright A.T. Chamillard. All Rights Reserved

#include <iostream>

/**
 * Exercise 1 solution
 * @return exit status
*/
int main()
{
    // Problem 1: output name
    std::cout << "My name: Dr. T\n";

    // Problem 2: output best friend or nemesis
    std::cout << "My nemesis: Administrators\n";
}