    #include<iostream>
    #include<string>
    #include"task1.h"
    using namespace std;
int main()
{
    Inventory o1(1,"Tomato",10),o2(2,"Potato",10);
    int x=1;
    o1.addProduct(x);
    
}